with open("suspicious_xor.jpg", "rb") as f:
    data = f.read()

eof = data.find(b'\xFF\xD9')
payload = data[eof+2:]

for key in range(256):
    out = bytearray()
    for b in payload:
        out.append(b ^ key)

    try:
        text = out.decode()
        if "PTIT" in text:
            print("KEY:", key)
            print(text)

            with open("xor_key.txt", "w") as f:
                f.write(str(key))

            with open("xor_recovered.txt", "w") as f:
                f.write(text)

            break
    except:
        pass
