with open("suspicious.jpg", "rb") as f:
    data = f.read()

eof = data.find(b'\xFF\xD9')

if eof == -1:
    result = "EOF_NOT_FOUND"
    print(result)
else:
    payload = data[eof+2:]
    print("EOF offset:", eof)

    if len(payload) > 0:
        result = "HIDDEN_PAYLOAD_DETECTED"
        print(result)
        print("Payload size:", len(payload))
    else:
        result = "NO_HIDDEN_PAYLOAD"
        print(result)

with open("detect_result.txt", "w") as f:
    f.write(result + "\n")
