with open("suspicious.jpg", "rb") as f:
    data = f.read()

eof = data.find(b'\xFF\xD9')
payload = data[eof+2:]

with open("recovered_secret.txt", "wb") as f:
    f.write(payload)

print("[+] Payload extracted")
