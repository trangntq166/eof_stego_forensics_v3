KEY = 23

with open("suspicious.jpg", "rb") as f:
    data = bytearray(f.read())

eof = data.find(b'\xFF\xD9')
payload = data[eof+2:]

enc = bytearray()
for b in payload:
    enc.append(b ^ KEY)

newdata = data[:eof+2] + enc

with open("suspicious_xor.jpg", "wb") as f:
    f.write(newdata)

print("[+] suspicious_xor.jpg created")
