secret = b"PTIT_FORENSIC_STEGANOGRAPHY"

jpeg = bytes([0xFF, 0xD8, 0xFF, 0xD9])

with open("cover.jpg", "wb") as f:
    f.write(jpeg)

with open("suspicious.jpg", "wb") as f:
    f.write(jpeg)
    f.write(secret)

print("[+] suspicious.jpg created")
