#!/bin/bash

echo "[1] Extract message"
python3 extract_dwt.py

echo "[2] Compute PSNR/SSIM"
python3 compute_metrics.py

echo "[3] Compute BER"
python3 evaluate.py

echo "[+] Analysis completed"
