import pywt
import numpy as np
from PIL import Image

INPUT = "../attacker/attacked/attacked_gaussian.png"
OUTPUT = "results/recovered_message.txt"

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) == 8:
            chars.append(chr(int(byte, 2)))
    return "".join(chars)

img = np.array(Image.open(INPUT).convert("L"), dtype=np.float32)

LL, (LH, HL, HH) = pywt.dwt2(img, "haar")
flat = LH.flatten()

length_bits = ""
for i in range(32):
    length_bits += "1" if flat[i] > 0 else "0"

payload_length = int(length_bits, 2)

payload_bits = ""
for i in range(32, 32 + payload_length):
    payload_bits += "1" if flat[i] > 0 else "0"

message = bits_to_text(payload_bits)

with open(OUTPUT, "w") as f:
    f.write(message)

print(f"[+] Recovered message: {message}")
print(f"[+] Saved to {OUTPUT}")
