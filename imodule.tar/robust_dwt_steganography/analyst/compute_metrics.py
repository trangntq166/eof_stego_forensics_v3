from PIL import Image
import numpy as np
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

COVER = "../sender/input/cover.png"
STEGO = "../sender/output/stego.png"
ATTACKED = "../attacker/attacked/attacked_gaussian.png"
METRICS = "metrics/metrics.txt"

cover = np.array(Image.open(COVER).convert("L"))
stego = np.array(Image.open(STEGO).convert("L"))
attacked = np.array(Image.open(ATTACKED).convert("L"))

psnr_stego = peak_signal_noise_ratio(cover, stego, data_range=255)
ssim_stego = structural_similarity(cover, stego, data_range=255)

psnr_attacked = peak_signal_noise_ratio(stego, attacked, data_range=255)
ssim_attacked = structural_similarity(stego, attacked, data_range=255)

with open(METRICS, "w") as f:
    f.write(f"PSNR cover-stego: {psnr_stego:.4f}\n")
    f.write(f"SSIM cover-stego: {ssim_stego:.4f}\n")
    f.write(f"PSNR stego-attacked: {psnr_attacked:.4f}\n")
    f.write(f"SSIM stego-attacked: {ssim_attacked:.4f}\n")

print("[+] Metrics saved")
print(f"[+] PSNR cover-stego: {psnr_stego:.4f}")
print(f"[+] SSIM cover-stego: {ssim_stego:.4f}")
