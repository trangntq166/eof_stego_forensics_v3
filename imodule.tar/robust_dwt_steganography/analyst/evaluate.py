ORIGINAL = "../sender/input/message.txt"
RECOVERED = "results/recovered_message.txt"
OUTPUT = "metrics/ber.txt"

with open(ORIGINAL, "r") as f:
    original = f.read().strip()

with open(RECOVERED, "r") as f:
    recovered = f.read().strip()

def text_to_bits(text):
    return "".join(format(ord(c), "08b") for c in text)

a = text_to_bits(original)
b = text_to_bits(recovered)

length = min(len(a), len(b))
errors = sum(1 for i in range(length) if a[i] != b[i])
errors += abs(len(a) - len(b))

ber = errors / max(len(a), 1)

with open(OUTPUT, "w") as f:
    f.write(f"Original: {original}\n")
    f.write(f"Recovered: {recovered}\n")
    f.write(f"Bit errors: {errors}\n")
    f.write(f"BER: {ber:.6f}\n")

print(f"[+] BER = {ber:.6f}")
