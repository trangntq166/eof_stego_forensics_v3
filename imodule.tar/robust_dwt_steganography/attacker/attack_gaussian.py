from PIL import Image
import numpy as np

INPUT = "stego.png"
OUTPUT = "attacked/attacked_gaussian.png"

img = np.array(Image.open(INPUT).convert("L"), dtype=np.float32)

noise = np.random.normal(0, 8, img.shape)
attacked = img + noise
attacked = np.clip(attacked, 0, 255).astype(np.uint8)

Image.fromarray(attacked).save(OUTPUT)

print(f"[+] Gaussian noise attack saved to {OUTPUT}")
