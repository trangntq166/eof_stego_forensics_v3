import cv2

INPUT = "stego.png"
OUTPUT = "attacked/attacked_blur.png"

img = cv2.imread(INPUT, cv2.IMREAD_GRAYSCALE)

blurred = cv2.GaussianBlur(img, (5, 5), 0)

cv2.imwrite(OUTPUT, blurred)

print(f"[+] Blur attack saved to {OUTPUT}")

