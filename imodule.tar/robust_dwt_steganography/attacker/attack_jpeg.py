from PIL import Image

INPUT = "stego.png"
OUTPUT = "attacked/attacked_jpeg.jpg"

img = Image.open(INPUT).convert("L")
img.save(OUTPUT, "JPEG", quality=55)

print(f"[+] JPEG compression attack saved to {OUTPUT}")
