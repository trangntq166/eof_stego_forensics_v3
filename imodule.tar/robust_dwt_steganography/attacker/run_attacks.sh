#!/bin/bash

echo "[1] Gaussian attack"
python3 attack_gaussian.py

echo "[2] Blur attack"
python3 attack_blur.py

echo "[3] JPEG attack"
python3 attack_jpeg.py

echo "[+] Attacks completed"
