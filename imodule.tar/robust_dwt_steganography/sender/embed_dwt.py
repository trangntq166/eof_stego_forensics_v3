import json
import pywt
import numpy as np
from PIL import Image

COVER_PATH = "input/cover.png"
MESSAGE_PATH = "input/message.txt"
STEGO_PATH = "output/stego.png"
KEY_PATH = "keys/embed_key.json"

DELTA = 8.0

def text_to_bits(text):
    return "".join(format(ord(c), "08b") for c in text)

cover = np.array(Image.open(COVER_PATH).convert("L"), dtype=np.float32)

with open(MESSAGE_PATH, "r") as f:
    message = f.read().strip()

payload_bits = text_to_bits(message)
length_bits = format(len(payload_bits), "032b")
bits = length_bits + payload_bits

LL, (LH, HL, HH) = pywt.dwt2(cover, "haar")

flat = LH.flatten()

if len(bits) > len(flat):
    raise ValueError("Message too large for selected DWT band")

for i, bit in enumerate(bits):
    value = flat[i]

    if bit == "1":
        if value < 0:
            value = abs(value)
        flat[i] = value + DELTA
    else:
        if value > 0:
            value = -abs(value)
        flat[i] = value - DELTA

LH2 = flat.reshape(LH.shape)

stego = pywt.idwt2((LL, (LH2, HL, HH)), "haar")
stego = np.clip(stego, 0, 255).astype(np.uint8)

Image.fromarray(stego).save(STEGO_PATH)

key = {
    "band": "LH",
    "wavelet": "haar",
    "delta": DELTA,
    "payload_bits": len(payload_bits),
    "total_bits": len(bits)
}

with open(KEY_PATH, "w") as f:
    json.dump(key, f, indent=4)

print("[+] Message embedded")
print(f"[+] Stego image saved to {STEGO_PATH}")
print(f"[+] Key saved to {KEY_PATH}")
