from PIL import Image, ImageDraw
import numpy as np

width, height = 512, 512
img = np.zeros((height, width), dtype=np.uint8)

for y in range(height):
    for x in range(width):
        img[y, x] = (x + y) % 256

image = Image.fromarray(img)
draw = ImageDraw.Draw(image)
draw.rectangle([120, 120, 390, 390], outline=180, width=5)
draw.text((170, 245), "PTIT DWT", fill=255)

image.save("input/cover.png")
print("[+] Created input/cover.png")
